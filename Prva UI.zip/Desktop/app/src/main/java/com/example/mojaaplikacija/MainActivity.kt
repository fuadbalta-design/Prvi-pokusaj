package com.example.servisautomobila

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnRezervisi: Button = findViewById(R.id.btnRezervisi)
        val btnUsluge: Button = findViewById(R.id.btnUsluge)
        val btnKontakt: Button = findViewById(R.id.btnKontakt)

        btnRezervisi.setOnClickListener {
            Toast.makeText(this, "Otvaram ekran za rezervaciju...", Toast.LENGTH_SHORT).show()
        }

        btnUsluge.setOnClickListener {
            Toast.makeText(this, "Prikazujem listu usluga...", Toast.LENGTH_SHORT).show()
        }

        btnKontakt.setOnClickListener {
            Toast.makeText(this, "Pozivam servis...", Toast.LENGTH_SHORT).show()
        }
    }
}
